#!/bin/bash
DEBUG=fastack:* npm start

