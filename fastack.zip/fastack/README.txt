Other sources used:

- NodeJS / NPM => https://nodejs.org/en/
- Angular => https://angular.io/
- React => https://reactjs.org/
- Vue => https://vuejs.org/
